// main.js

document.addEventListener('DOMContentLoaded', () => {
    const journeysTab = document.getElementById('journeys-tab');
    const allHistoryTab = document.getElementById('all-history-tab');
    const contentArea = document.getElementById('content-area');
    const searchBar = document.getElementById('search-bar');

    let fullHistory = [];
    let currentJourneys = [];

    function showOnboarding() {
        chrome.storage.local.get(['onboardingComplete'], (result) => {
            if (result.onboardingComplete) return;

            const backdrop = document.createElement('div');
            backdrop.className = 'modal-backdrop';
            // ... (rest of onboarding modal code is unchanged)
        });
    }

    function renderJourneys(journeys) {
        if (!journeys || journeys.length === 0) {
            contentArea.innerHTML = '<p>No journeys could be created from your recent history.</p>';
            return;
        }
        // ... (rest of renderJourneys code is unchanged)
    }

    async function loadAndDisplayJourneys() {
        contentArea.innerHTML = '<p>✨ Analyzing your history with AI...</p>';
        try {
            const result = await createJourneysFromHistory(fullHistory);
            currentJourneys = result.journeys;
            renderJourneys(currentJourneys);
        } catch (error) {
            console.error("Failed to load journeys:", error);
            contentArea.innerHTML = `<p style="color: red;">Error: Could not analyze browsing history. Please try again later.</p>`;
        }
    }

    function renderAllHistory(historyItems) {
        if (!historyItems || historyItems.length === 0) {
            contentArea.innerHTML = '<p>No browsing history found.</p>';
            return;
        }
        // ... (rest of renderAllHistory code is unchanged)
    }
    
    // ... (renderHistoryList, filterHistoryByDays, handleSearch functions are unchanged)


    function setActiveTab(tab) {
        searchBar.value = '';
        journeysTab.classList.remove('active');
        allHistoryTab.classList.remove('active');
        tab.classList.add('active');

        if (tab === journeysTab) {
            // Handle empty history edge case
            if (fullHistory.length === 0) {
                contentArea.innerHTML = '<p>No browsing history to analyze. Start browsing to create Journeys!</p>';
                return;
            }
            loadAndDisplayJourneys();
        } else {
            renderAllHistory(fullHistory);
        }
    }

    // --- Event Listeners ---
    // ... (listeners are unchanged)


    // --- Initial Load ---
    showOnboarding();
    chrome.history.search({ text: '', maxResults: 1000, startTime: new Date().setDate(new Date().getDate() - 90) }, (historyItems) => {
        fullHistory = historyItems || []; // Ensure fullHistory is always an array
        setActiveTab(journeysTab); // Default to journeys view
    });
});
