// history_processor.js

/**
 * Constructs a detailed prompt for the gemini-3-flash-preview model to analyze browser history.
 * @param {Array<Object>} historyItems - An array of Chrome history items, pruned for brevity.
 * @returns {string} The formatted prompt string.
 */
function createPrompt(historyItems) {
    const formattedHistory = historyItems.map(item => `{ "title": "${(item.title || "").replace(/"/g, "'")}", "url": "${item.url}" }`).join(',\n');

    return `
You are an expert data analyst and personal assistant. Your task is to analyze a user's browsing history and group related pages into coherent "Journeys". A Journey represents a focused task, research session, or a single topic of interest.

Analyze the following list of browser history items (in JSON format):
[
${formattedHistory}
]

Based on the titles and URLs, perform the following actions:
1.  Group the items into distinct Journeys. A Journey should have at least 2 related pages. Do not include unrelated pages in a journey.
2.  For each Journey, create a short, descriptive, and insightful title (e.g., "Researching 'Manifest V3'", "Planning a Trip to Lisbon", "Shopping for a New Laptop").
3.  For each Journey, include the original page objects that belong to it.
4.  Rank the Journeys in order of relevance and significance, with the most important one appearing first. Consider factors like the number of pages, diversity of domains, and inferred user intent.
5.  Return the output as a single, clean, parseable JSON object. The JSON object should have a single key, "journeys", which is an array of journey objects.

The final JSON output should look like this:
{
  "journeys": [
    {
      "title": "Example: AI Development Research",
      "relevance": 0.9,
      "pages": [
        { "title": "Gemini API Docs", "url": "https://ai.google.dev/docs" },
        { "title": "React Tutorial", "url": "https://react.dev/learn" }
      ]
    }
  ]
}

Do not include any journeys with fewer than 2 pages. Ensure the JSON is perfectly formatted.
    `;
}

/**
 * Simulates calling an AI model to group history items into journeys.
 * This function includes error handling and response validation.
 *
 * @param {Array<Object>} historyItems - An array of Chrome history items.
 * @returns {Promise<Object>} A promise that resolves to an object containing the processed journeys.
 * @throws {Error} If the AI response is invalid or the API call fails.
 */
async function createJourneysFromHistory(historyItems) {
    if (!historyItems || historyItems.length === 0) {
        return { journeys: [] };
    }

    const prunedHistory = historyItems.slice(0, 100);
    const prompt = createPrompt(prunedHistory);

    console.log("--- SIMULATED AI PROMPT ---");
    console.log(prompt);
    console.log("---------------------------");

    try {
        // --- SIMULATED API CALL ---
        await new Promise(resolve => setTimeout(resolve, 800));

        const mockJsonResponse = `
        {
            "journeys": [
                {
                    "title": "AI Development Research",
                    "relevance": 0.95,
                    "pages": [
                        { "title": "Gemini API: Get Started", "url": "https://ai.google.dev/docs/get_started", "lastVisitTime": ${Date.now() - 100000} },
                        { "title": "What is Manifest V3? - Chrome Developers", "url": "https://developer.chrome.com/docs/extensions/develop/concepts/manifest-v3", "lastVisitTime": ${Date.now() - 90000} },
                        { "title": "Using Vanilla JS for Chrome Extensions", "url": "https://stackoverflow.com/questions/12345/vanilla-js-chrome-ext", "lastVisitTime": ${Date.now() - 80000} }
                    ]
                },
                {
                    "title": "Planning a Trip to Japan",
                    "relevance": 0.8,
                    "pages": [
                        { "title": "Flights from SFO to NRT", "url": "https://www.google.com/flights", "lastVisitTime": ${Date.now() - 500000} },
                        { "title": "Best Hotels in Tokyo", "url": "https://www.booking.com/city/jp/tokyo.html", "lastVisitTime": ${Date.now() - 450000} },
                        { "title": "Japan Rail Pass Official Site", "url": "https://www.jrailpass.com/", "lastVisitTime": ${Date.now() - 400000} }
                    ]
                }
            ]
        }
        `;

        // --- RESPONSE VALIDATION ---
        const mockResponse = JSON.parse(mockJsonResponse);

        if (!mockResponse || !Array.isArray(mockResponse.journeys)) {
            throw new Error("Invalid AI response format: 'journeys' array not found.");
        }

        console.log("--- SIMULATED AI RESPONSE (VALIDATED) ---");
        console.log(mockResponse);
        console.log("---------------------------------------");
        
        // Merge AI response with original history data for completeness
        mockResponse.journeys.forEach(journey => {
            journey.pages = journey.pages.map(page => {
                const original = historyItems.find(item => item.url === page.url);
                return original || page;
            });
        });

        return mockResponse;

    } catch (error) {
        console.error("AI processing failed:", error);
        // In a real app, you might want to have a fallback mechanism here.
        // For now, we re-throw the error to be handled by the UI.
        throw new Error("Failed to process browsing history with AI.");
    }
}